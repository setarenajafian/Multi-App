﻿using System;

namespace Calculator
{
    public class ProPrime : Calculator
    {
        public bool IsPrime(uint num)
        {
            for (uint i = 3; i <= Math.Sqrt(num); i += 2)
            {
                if (num % i == 0) return false;
            }
            return true;
        }
    }
}
