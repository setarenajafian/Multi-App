﻿using System;

namespace Keyboard
{
    public class GetNumber : Keyboard
    {
        public uint GetUserInput()
        {
            string input = string.Empty;
            Console.Write("enter a number: ");

            while (true)
            {
                var key = Console.ReadKey(intercept: true); 
                if (key.Key == ConsoleKey.Enter)
                {
                    if (uint.TryParse(input, out uint number))
                    {
                        Console.WriteLine();
                        return number;
                    }
                   
                }
                else if (char.IsDigit(key.KeyChar))
                {
                    input += key.KeyChar;
                    Console.Write(key.KeyChar);
                }
                else
                {
                    Console.Beep();
                }
            }
        }
    }
}
