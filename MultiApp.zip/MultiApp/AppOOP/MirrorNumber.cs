﻿namespace Calculator
{
    public class MirrorNumber : Calculator
    {
        public bool IsMirrorNumber(uint num)
        {
            uint original = num, reverse = 0;
            while (num > 0)
            {
                reverse = reverse * 10 + num % 10;
                num /= 10;
            }
            return original == reverse;
        }
    }
}
