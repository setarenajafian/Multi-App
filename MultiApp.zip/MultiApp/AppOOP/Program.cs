﻿

class Program
{
    static void Main()
    {
        while (true)
        {
            Keyboard.GetHomeControl homeControl = new Keyboard.GetHomeControl();

            Console.Clear();
            Console.WriteLine("Hi, Which program do you want?\n");
            Console.WriteLine("a) Prime Number\nb) Mirror Number\nc) Decision Tree");
            Console.Write("\nChoose an option (a/b/c):\n ");

            char choice = homeControl.GetChoice();
            Console.Clear();

            switch (choice)
            {
                case 'a':
                    PrimeNumber();
                    break;
                case 'b':
                    MirrorNumber();
                    break;
                case 'c':
                    DecisionTree();
                    break;
                default:
                    Console.WriteLine();
                    continue;
            }
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\nPress any key to restart");
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
        }
    }

    static void PrimeNumber()
    {
        Keyboard.GetNumber getNumber = new Keyboard.GetNumber();
        Console.WriteLine("\t\t\t\t\t\t Prime Number Program \n");

        uint number = getNumber.GetUserInput();

        if (number < 1000)
        {
            Calculator.SimplePrime simplePrime = new Calculator.SimplePrime();
            Console.WriteLine(simplePrime.IsPrime(number) ? $"{number} is a prime number." : $"{number} is not a prime number.");
        }
        else
        {
            Calculator.ProPrime proPrime = new Calculator.ProPrime();
            Console.WriteLine(proPrime.IsPrime(number) ? $"{number} is a prime number." : $"{number} is not a prime number.");
        }
    }

    static void MirrorNumber()
    {
        Keyboard.GetNumber getNumber = new Keyboard.GetNumber();
        Console.WriteLine("\t\t\t\t\t\t Mirror Number Program \n");
        uint number = getNumber.GetUserInput();

        Calculator.MirrorNumber mirrorNumber = new Calculator.MirrorNumber();
        Console.WriteLine(mirrorNumber.IsMirrorNumber(number) ? $"{number} is a mirror number." : $"{number} is not a mirror number.");
    }

    static void DecisionTree()
    {
        Calculator.DecisionTree decisionTree = new Calculator.DecisionTree();
        decisionTree.Execute();
    }
}