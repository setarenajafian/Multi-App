﻿namespace Calculator
{
    public abstract class Calculator
    {
        
    }
}
