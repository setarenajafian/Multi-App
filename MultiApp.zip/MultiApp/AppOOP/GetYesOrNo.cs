﻿using System;

namespace Keyboard
{
    public class GetYesOrNo : Keyboard
    {
        public char GetResponse(string question)
        {
            Console.WriteLine(question);

            while (true)
            {
                var key = Console.ReadKey(intercept: true); 
                if (key.KeyChar == 'y' || key.KeyChar == 'n')
                {
                    Console.Write(key.KeyChar);

                    return key.KeyChar;
                }
                else
                {
                    Console.Beep();
                }
            }
        }
    }
}
