﻿using System;

namespace Calculator
{
    public class SimplePrime : Calculator
    {
        public bool IsPrime(uint num)
        {
            for (uint i = 2; i <num; i++)
            {
                if (num % i == 0) return false;
            }
            return true;
        }
    }
}
