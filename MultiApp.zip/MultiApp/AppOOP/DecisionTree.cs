﻿using System;
using Keyboard;

namespace Calculator
{
    public class DecisionTree : Calculator
    {
        public void Execute()
        {
            GetYesOrNo getYesOrNo = new GetYesOrNo();
            int low = 1, high = 50;

            Console.WriteLine("Think of a number between 1 and 50.\n");
            Console.WriteLine("I will ask some (yes/no) questions to guess your number.\n");

            while (low < high)
            {
                int mid = (low + high) / 2;
                char response = getYesOrNo.GetResponse($"\nIs your number greater than {mid}? (y/n)");

                if (response == 'y')
                {
                    low = mid + 1; 
                }
                else
                {
                    high = mid;
                }
            }

            Console.WriteLine($"Your number is {low}!");
        }
    }
}



