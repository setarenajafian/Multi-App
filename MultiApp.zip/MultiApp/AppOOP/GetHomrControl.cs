﻿using System;

namespace Keyboard
{
    public class GetHomeControl : Keyboard
    {
        public char GetChoice()
        {
            char choice;
            do
            {
                var key = Console.ReadKey(intercept: true); 
                choice = key.KeyChar;
                if (choice == 'a' || choice == 'b' || choice == 'c')
                {
                    Console.Write(choice); 
                    break;
                }
                else
                {
                    Console.Beep();
                }
            } while (true);

            return choice;
        }
    }
}
